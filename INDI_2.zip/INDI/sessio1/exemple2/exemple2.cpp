#include <QApplication>
#include <QPushButton>
#include <QFrame>
#include <iostream>

void msg() {
	std::cout << "hola" << std::endl;
}

int main(int argc, char **argv) {

	QApplication a(argc,argv);

	// Qfram es un marco donde se puede añadir información. NULL indica que QFRAMS no tiene padre.
	// El 0 indica que no tiene padre. 
	QFrame F(0, NULL); 
	QPushButton hello("Hello world!",&F); // El padre del button es el frame F

	// conectamos el qbutton que al hacer click, la F hace el metodo close().
	a.connect(&hello, SIGNAL(clicked()), &F, SLOT(close()));

	// Lo conectamos a otro signal.
	// a.connect(&hello, SIGNAL(clicked()), &F, SLOT(msg()));

	hello.resize(200,200);
	F.show();
	return a.exec();
}