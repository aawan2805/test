qmake // Generates makefile
make
