#include <QApplication>
#include <QPushButton>

int main(int argc, char **argv) {
	QApplication a(argc,argv);
	// -------------------------------------

	QPushButton hello("Hello Eugeni stupid ass bitch nigga!", 0);
	// Same as v
//	QPushButton hello("Hello world!", NULL);

	hello.resize(300,30);
	hello.show();

	// -------------------------------------
	return a.exec();
}
