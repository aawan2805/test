#include <QApplication>
#include "EcoText.h"

int main(int argc, char** argv){
    QApplication app(argc, argv);
    EcoText form;
    form.show();

    return app.exec();
}