#include "ui_EcoText.h"

class EcoText : public QWidget {
    Q_OBJECT
    public: 
        EcoText(QWidget *parent = NULL);
    private:
        Ui::EcoText ui;
    private slots:
        void esborra();
        void CanviInputText();
};