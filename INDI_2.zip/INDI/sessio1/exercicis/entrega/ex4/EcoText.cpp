#include "EcoText.h"
#include <iostream>
#include <QDebug>

EcoText::EcoText(QWidget* parent): QWidget(parent) {
    ui.setupUi(this);
    this->setWindowTitle("Eco de text");

    connect(ui.esborra_button, SIGNAL(clicked()), this, SLOT(esborra()));
    connect(ui.text_replicat, SIGNAL(textChanged()), this, SLOT(CanviInputText()));
}

void EcoText::esborra() {
    ui.text_replicat->setText("");
    ui.text_original->setText("");
}

void EcoText::CanviInputText() {
    QString str = ui.text_replicat->toPlainText();
    // esborra();
    // ui.text_replicat->setText("");
    ui.text_original->setText(str);

}
