/********************************************************************************
** Form generated from reading UI file 'EcoText.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ECOTEXT_H
#define UI_ECOTEXT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_EcoText
{
public:
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLineEdit *text_original;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_2;
    QTextEdit *text_replicat;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout;
    QPushButton *esborra_button;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_2;

    void setupUi(QWidget *EcoText)
    {
        if (EcoText->objectName().isEmpty())
            EcoText->setObjectName(QString::fromUtf8("EcoText"));
        EcoText->resize(400, 300);
        verticalLayout_3 = new QVBoxLayout(EcoText);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(EcoText);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setFamily(QString::fromUtf8("Fira Sans"));
        font.setPointSize(20);
        font.setBold(true);
        font.setItalic(true);
        font.setUnderline(false);
        font.setWeight(75);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("font: 600 italic 20pt \"Fira Sans\";"));

        verticalLayout->addWidget(label);

        text_original = new QLineEdit(EcoText);
        text_original->setObjectName(QString::fromUtf8("text_original"));

        verticalLayout->addWidget(text_original);


        verticalLayout_3->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_2 = new QLabel(EcoText);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setStyleSheet(QString::fromUtf8("font: 600 italic 20pt \"Fira Sans\";"));

        verticalLayout_2->addWidget(label_2);

        text_replicat = new QTextEdit(EcoText);
        text_replicat->setObjectName(QString::fromUtf8("text_replicat"));

        verticalLayout_2->addWidget(text_replicat);


        verticalLayout_3->addLayout(verticalLayout_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        esborra_button = new QPushButton(EcoText);
        esborra_button->setObjectName(QString::fromUtf8("esborra_button"));
        esborra_button->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));

        horizontalLayout->addWidget(esborra_button);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        pushButton_2 = new QPushButton(EcoText);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(204, 0, 0);"));

        horizontalLayout->addWidget(pushButton_2);


        verticalLayout_3->addLayout(horizontalLayout);

        verticalLayout_3->setStretch(1, 1);

        retranslateUi(EcoText);
        QObject::connect(text_original, SIGNAL(textChanged(QString)), text_replicat, SLOT(setText(QString)));
        QObject::connect(pushButton_2, SIGNAL(clicked()), EcoText, SLOT(close()));

        QMetaObject::connectSlotsByName(EcoText);
    } // setupUi

    void retranslateUi(QWidget *EcoText)
    {
        EcoText->setWindowTitle(QApplication::translate("EcoText", "Form", nullptr));
        label->setText(QApplication::translate("EcoText", "Edita un text:", nullptr));
        label_2->setText(QApplication::translate("EcoText", "Text replicat", nullptr));
        esborra_button->setText(QApplication::translate("EcoText", "Neteja", nullptr));
        pushButton_2->setText(QApplication::translate("EcoText", "Sortir", nullptr));
    } // retranslateUi

};

namespace Ui {
    class EcoText: public Ui_EcoText {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ECOTEXT_H
