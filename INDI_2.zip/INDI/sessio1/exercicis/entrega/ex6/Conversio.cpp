#include "Conversio.h"
#include <iostream>
#include <QDebug>

Conversio::Conversio(QWidget* parent): QWidget(parent) {
    ui.setupUi(this);
    this->setWindowTitle("Conversor");
}
