/********************************************************************************
** Form generated from reading UI file 'Conversio.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONVERSIO_H
#define UI_CONVERSIO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDial>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Conversio
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QSpinBox *number_sb;
    QDial *dial;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLCDNumber *binary_lcd;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLCDNumber *octal_lcd;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QLCDNumber *hex_lcd;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton;

    void setupUi(QWidget *Conversio)
    {
        if (Conversio->objectName().isEmpty())
            Conversio->setObjectName(QString::fromUtf8("Conversio"));
        Conversio->resize(391, 299);
        verticalLayout = new QVBoxLayout(Conversio);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(Conversio);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        number_sb = new QSpinBox(Conversio);
        number_sb->setObjectName(QString::fromUtf8("number_sb"));
        number_sb->setMinimum(0);
        number_sb->setMaximum(200);

        horizontalLayout->addWidget(number_sb);

        dial = new QDial(Conversio);
        dial->setObjectName(QString::fromUtf8("dial"));
        dial->setMinimum(1);
        dial->setMaximum(200);

        horizontalLayout->addWidget(dial);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(Conversio);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setStyleSheet(QString::fromUtf8("color: rgb(5, 135, 45);"));

        horizontalLayout_2->addWidget(label_2);

        binary_lcd = new QLCDNumber(Conversio);
        binary_lcd->setObjectName(QString::fromUtf8("binary_lcd"));
        binary_lcd->setStyleSheet(QString::fromUtf8("background-color: rgb(5, 135, 45);\n"
"color: rgb(255, 255, 255);"));
        binary_lcd->setFrameShadow(QFrame::Plain);
        binary_lcd->setDigitCount(10);
        binary_lcd->setMode(QLCDNumber::Bin);

        horizontalLayout_2->addWidget(binary_lcd);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_3 = new QLabel(Conversio);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));

        horizontalLayout_3->addWidget(label_3);

        octal_lcd = new QLCDNumber(Conversio);
        octal_lcd->setObjectName(QString::fromUtf8("octal_lcd"));
        octal_lcd->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(52, 101, 164);"));
        octal_lcd->setFrameShadow(QFrame::Plain);
        octal_lcd->setDigitCount(10);
        octal_lcd->setMode(QLCDNumber::Oct);

        horizontalLayout_3->addWidget(octal_lcd);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_4 = new QLabel(Conversio);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setStyleSheet(QString::fromUtf8("color: rgb(239, 41, 41);"));

        horizontalLayout_4->addWidget(label_4);

        hex_lcd = new QLCDNumber(Conversio);
        hex_lcd->setObjectName(QString::fromUtf8("hex_lcd"));
        hex_lcd->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(239, 41, 41);"));
        hex_lcd->setFrameShadow(QFrame::Plain);
        hex_lcd->setDigitCount(10);
        hex_lcd->setMode(QLCDNumber::Hex);

        horizontalLayout_4->addWidget(hex_lcd);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer);

        pushButton = new QPushButton(Conversio);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        horizontalLayout_5->addWidget(pushButton);


        verticalLayout->addLayout(horizontalLayout_5);


        retranslateUi(Conversio);
        QObject::connect(pushButton, SIGNAL(clicked()), Conversio, SLOT(close()));
        QObject::connect(number_sb, SIGNAL(valueChanged(int)), dial, SLOT(setValue(int)));
        QObject::connect(dial, SIGNAL(sliderMoved(int)), number_sb, SLOT(setValue(int)));
        QObject::connect(number_sb, SIGNAL(valueChanged(int)), binary_lcd, SLOT(display(int)));
        QObject::connect(number_sb, SIGNAL(valueChanged(int)), octal_lcd, SLOT(display(int)));
        QObject::connect(number_sb, SIGNAL(valueChanged(int)), hex_lcd, SLOT(display(int)));

        QMetaObject::connectSlotsByName(Conversio);
    } // setupUi

    void retranslateUi(QWidget *Conversio)
    {
        Conversio->setWindowTitle(QApplication::translate("Conversio", "Form", nullptr));
        label->setText(QApplication::translate("Conversio", "Escriu un nombre natural:", nullptr));
        label_2->setText(QApplication::translate("Conversio", "Binari", nullptr));
        label_3->setText(QApplication::translate("Conversio", "Octal", nullptr));
        label_4->setText(QApplication::translate("Conversio", "Hexadecimal", nullptr));
        pushButton->setText(QApplication::translate("Conversio", "Surt", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Conversio: public Ui_Conversio {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONVERSIO_H
