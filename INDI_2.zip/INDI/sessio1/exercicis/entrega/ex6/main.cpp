#include <QApplication>
#include "Conversio.h"

int main(int argc, char** argv){
    QApplication app(argc, argv);
    Conversio form;
    form.show();

    return app.exec();
}