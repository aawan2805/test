#include "ui_Conversio.h"

class Conversio : public QWidget {
    Q_OBJECT
    public: 
        Conversio(QWidget *parent = NULL);
    private:
        Ui::Conversio ui;
};