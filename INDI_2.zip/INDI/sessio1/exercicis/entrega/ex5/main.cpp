#include <QApplication>
#include "DialMagic.h"

int main(int argc, char** argv){
    QApplication app(argc, argv);
    DialMagic form;
    form.show();

    return app.exec();
}