#include "ui_DialMagic.h"

class DialMagic : public QWidget {
    Q_OBJECT
    public: 
        DialMagic(QWidget *parent = NULL);
    private:
        Ui::DialMagic ui;
};