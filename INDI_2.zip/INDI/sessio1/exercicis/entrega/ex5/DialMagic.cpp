#include "DialMagic.h"
#include <iostream>
#include <QDebug>

DialMagic::DialMagic(QWidget* parent): QWidget(parent) {
    ui.setupUi(this);
    this->setWindowTitle("Dial màgic");
}
