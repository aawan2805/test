/********************************************************************************
** Form generated from reading UI file 'DialMagic.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALMAGIC_H
#define UI_DIALMAGIC_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDial>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialMagic
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QDial *dial;
    QLabel *label;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *sortir;

    void setupUi(QWidget *DialMagic)
    {
        if (DialMagic->objectName().isEmpty())
            DialMagic->setObjectName(QString::fromUtf8("DialMagic"));
        DialMagic->resize(400, 300);
        verticalLayout = new QVBoxLayout(DialMagic);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        dial = new QDial(DialMagic);
        dial->setObjectName(QString::fromUtf8("dial"));
        dial->setMinimum(1);
        dial->setMaximum(50);

        horizontalLayout_2->addWidget(dial);

        label = new QLabel(DialMagic);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_2->addWidget(label);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        sortir = new QPushButton(DialMagic);
        sortir->setObjectName(QString::fromUtf8("sortir"));

        horizontalLayout->addWidget(sortir);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(DialMagic);
        QObject::connect(sortir, SIGNAL(clicked()), DialMagic, SLOT(close()));
        QObject::connect(dial, SIGNAL(valueChanged(int)), label, SLOT(setNum(int)));
        QObject::connect(dial, SIGNAL(sliderReleased()), label, SLOT(hide()));
        QObject::connect(dial, SIGNAL(valueChanged(int)), label, SLOT(show()));

        QMetaObject::connectSlotsByName(DialMagic);
    } // setupUi

    void retranslateUi(QWidget *DialMagic)
    {
        DialMagic->setWindowTitle(QApplication::translate("DialMagic", "Form", nullptr));
        label->setText(QString());
        sortir->setText(QApplication::translate("DialMagic", "Quit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialMagic: public Ui_DialMagic {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALMAGIC_H
