#include "ui_Rellotge.h"

class Form : public QWidget {
    Q_OBJECT
    public: 
        Form(QWidget *parent = NULL);
    private:
        Ui::Form ui;
};