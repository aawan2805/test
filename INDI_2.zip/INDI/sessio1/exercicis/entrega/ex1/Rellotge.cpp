#include "Rellotge.h"
#include <iostream>
// #include <QDebug>

double result = 0.0;

Form::Form(QWidget* parent): QWidget(parent) {
    ui.setupUi(this);
    this->setWindowTitle("Rellotge digital");

    ui.dial_hours->setMaximum(23);
    ui.dial_minutes->setMaximum(59);
}

// void Form::checkboxChanges(){
//     int val = ui.spinBox->value();
//     if(ui.radioButton->isChecked()){
//         // From KM to miles
//         val = (int) val/1.60934;
//     } else {
//         val = (int) val*1.60934;
//     }
//     ui.spinBox_2->setValue(val);
// }
