/********************************************************************************
** Form generated from reading UI file 'Rellotge.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RELLOTGE_H
#define UI_RELLOTGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDial>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form
{
public:
    QGridLayout *gridLayout_3;
    QGridLayout *gridLayout;
    QDial *dial_hours;
    QLabel *label;
    QLCDNumber *lcd_hours;
    QGridLayout *gridLayout_2;
    QLabel *label_2;
    QLCDNumber *lcd_minutes;
    QDial *dial_minutes;
    QPushButton *pushButton;

    void setupUi(QWidget *Form)
    {
        if (Form->objectName().isEmpty())
            Form->setObjectName(QString::fromUtf8("Form"));
        Form->resize(357, 309);
        gridLayout_3 = new QGridLayout(Form);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        dial_hours = new QDial(Form);
        dial_hours->setObjectName(QString::fromUtf8("dial_hours"));

        gridLayout->addWidget(dial_hours, 2, 0, 1, 1);

        label = new QLabel(Form);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        lcd_hours = new QLCDNumber(Form);
        lcd_hours->setObjectName(QString::fromUtf8("lcd_hours"));

        gridLayout->addWidget(lcd_hours, 1, 0, 1, 1);


        gridLayout_3->addLayout(gridLayout, 0, 0, 1, 1);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label_2 = new QLabel(Form);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_2->addWidget(label_2, 0, 0, 1, 1);

        lcd_minutes = new QLCDNumber(Form);
        lcd_minutes->setObjectName(QString::fromUtf8("lcd_minutes"));

        gridLayout_2->addWidget(lcd_minutes, 1, 0, 1, 1);

        dial_minutes = new QDial(Form);
        dial_minutes->setObjectName(QString::fromUtf8("dial_minutes"));

        gridLayout_2->addWidget(dial_minutes, 2, 0, 1, 1);


        gridLayout_3->addLayout(gridLayout_2, 0, 1, 1, 1);

        pushButton = new QPushButton(Form);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout_3->addWidget(pushButton, 1, 1, 1, 1);


        retranslateUi(Form);
        QObject::connect(pushButton, SIGNAL(clicked()), Form, SLOT(close()));
        QObject::connect(dial_hours, SIGNAL(sliderMoved(int)), lcd_hours, SLOT(display(int)));
        QObject::connect(dial_minutes, SIGNAL(sliderMoved(int)), lcd_minutes, SLOT(display(int)));

        QMetaObject::connectSlotsByName(Form);
    } // setupUi

    void retranslateUi(QWidget *Form)
    {
        Form->setWindowTitle(QApplication::translate("Form", "Form", nullptr));
        label->setText(QApplication::translate("Form", "Hours", nullptr));
        label_2->setText(QApplication::translate("Form", "Minutes", nullptr));
        pushButton->setText(QApplication::translate("Form", "Exit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Form: public Ui_Form {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RELLOTGE_H
