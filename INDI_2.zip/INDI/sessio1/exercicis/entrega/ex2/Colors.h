#include "ui_Colors.h"

class Colors : public QWidget {
    Q_OBJECT
    public: 
        Colors(QWidget *parent = NULL);
    private:
        Ui::Colors ui;
    private slots:
        void selectedRed();
        void selectedGreen();
        void selectedBlue();
};