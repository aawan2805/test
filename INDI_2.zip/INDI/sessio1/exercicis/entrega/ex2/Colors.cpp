#include "Colors.h"
#include <iostream>
// #include <QDebug>

double result = 0.0;

Colors::Colors(QWidget* parent): QWidget(parent) {
    ui.setupUi(this);
    this->setWindowTitle("Colors");

    connect(ui.radio_verd, SIGNAL(clicked()), this, SLOT(selectedGreen()));
    connect(ui.radio_vermell, SIGNAL(clicked()), this, SLOT(selectedRed()));
    connect(ui.radio_blau, SIGNAL(clicked()), this, SLOT(selectedBlue()));
}

void Colors::selectedRed() {
    ui.test_verd->setDisabled(true);
    ui.text_blau->setDisabled(true);
    ui.text_vermell->setDisabled(false);
}

void Colors::selectedGreen() {
    ui.test_verd->setDisabled(false);
    ui.text_blau->setDisabled(true);
    ui.text_vermell->setDisabled(true);
}

void Colors::selectedBlue() {
    ui.test_verd->setDisabled(true);
    ui.text_blau->setDisabled(false);
    ui.text_vermell->setDisabled(true);    
}
