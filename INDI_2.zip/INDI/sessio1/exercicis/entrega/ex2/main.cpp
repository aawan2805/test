#include <QApplication>
#include "Colors.h"

int main(int argc, char** argv){
    QApplication app(argc, argv);
    Colors form;
    form.show();

    return app.exec();
}