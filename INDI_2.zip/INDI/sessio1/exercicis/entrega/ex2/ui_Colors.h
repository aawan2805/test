/********************************************************************************
** Form generated from reading UI file 'Colors.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_COLORS_H
#define UI_COLORS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Colors
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QRadioButton *radio_vermell;
    QRadioButton *radio_verd;
    QRadioButton *radio_blau;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *verticalLayout_2;
    QLabel *text_vermell;
    QLabel *test_verd;
    QLabel *text_blau;
    QSpacerItem *verticalSpacer;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QWidget *Colors)
    {
        if (Colors->objectName().isEmpty())
            Colors->setObjectName(QString::fromUtf8("Colors"));
        Colors->resize(205, 182);
        gridLayout = new QGridLayout(Colors);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        radio_vermell = new QRadioButton(Colors);
        radio_vermell->setObjectName(QString::fromUtf8("radio_vermell"));
        radio_vermell->setChecked(true);

        verticalLayout->addWidget(radio_vermell);

        radio_verd = new QRadioButton(Colors);
        radio_verd->setObjectName(QString::fromUtf8("radio_verd"));

        verticalLayout->addWidget(radio_verd);

        radio_blau = new QRadioButton(Colors);
        radio_blau->setObjectName(QString::fromUtf8("radio_blau"));

        verticalLayout->addWidget(radio_blau);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);

        pushButton = new QPushButton(Colors);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout->addWidget(pushButton, 2, 2, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 2, 0, 1, 1);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        text_vermell = new QLabel(Colors);
        text_vermell->setObjectName(QString::fromUtf8("text_vermell"));
        text_vermell->setStyleSheet(QString::fromUtf8("background-color: red"));
        text_vermell->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(text_vermell);

        test_verd = new QLabel(Colors);
        test_verd->setObjectName(QString::fromUtf8("test_verd"));
        test_verd->setEnabled(false);
        test_verd->setStyleSheet(QString::fromUtf8("background-color: rgb(5, 135, 45)"));
        test_verd->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(test_verd);

        text_blau = new QLabel(Colors);
        text_blau->setObjectName(QString::fromUtf8("text_blau"));
        text_blau->setEnabled(false);
        text_blau->setStyleSheet(QString::fromUtf8("background-color: blue"));
        text_blau->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(text_blau);


        gridLayout->addLayout(verticalLayout_2, 0, 2, 1, 1);

        verticalSpacer = new QSpacerItem(1, 1, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 1, 2, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 0, 1, 1, 1);


        retranslateUi(Colors);
        QObject::connect(pushButton, SIGNAL(clicked()), Colors, SLOT(close()));

        QMetaObject::connectSlotsByName(Colors);
    } // setupUi

    void retranslateUi(QWidget *Colors)
    {
        Colors->setWindowTitle(QApplication::translate("Colors", "Form", nullptr));
        radio_vermell->setText(QApplication::translate("Colors", "Vermell", nullptr));
        radio_verd->setText(QApplication::translate("Colors", "Verd", nullptr));
        radio_blau->setText(QApplication::translate("Colors", "Blau", nullptr));
        pushButton->setText(QApplication::translate("Colors", "Exit", nullptr));
#ifndef QT_NO_WHATSTHIS
        text_vermell->setWhatsThis(QApplication::translate("Colors", "Color vermell", nullptr));
#endif // QT_NO_WHATSTHIS
        text_vermell->setText(QApplication::translate("Colors", "VERMELL", nullptr));
        test_verd->setText(QApplication::translate("Colors", "VERD", nullptr));
        text_blau->setText(QApplication::translate("Colors", "BLAU", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Colors: public Ui_Colors {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_COLORS_H
