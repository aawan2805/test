#include "ui_NumeroText.h"

class NumeroText : public QWidget {
    Q_OBJECT
    public: 
        NumeroText(QWidget *parent = NULL);
    private:
        Ui::NumeroText ui;
    private slots:
        void esborra();
        void CanviInputNumero(QString);
        void CanviInputText(QString);
};