#include <QApplication>
#include "NumeroText.h"

int main(int argc, char** argv){
    QApplication app(argc, argv);
    NumeroText form;
    form.show();

    return app.exec();
}