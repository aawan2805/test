/********************************************************************************
** Form generated from reading UI file 'NumeroText.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NUMEROTEXT_H
#define UI_NUMEROTEXT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NumeroText
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QSpacerItem *horizontalSpacer;
    QLineEdit *number_input;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer_2;
    QLineEdit *text_input;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *erase_button;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *exit_button;

    void setupUi(QWidget *NumeroText)
    {
        if (NumeroText->objectName().isEmpty())
            NumeroText->setObjectName(QString::fromUtf8("NumeroText"));
        NumeroText->resize(340, 251);
        verticalLayout = new QVBoxLayout(NumeroText);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(NumeroText);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        number_input = new QLineEdit(NumeroText);
        number_input->setObjectName(QString::fromUtf8("number_input"));
        number_input->setStyleSheet(QString::fromUtf8("color: red"));

        horizontalLayout->addWidget(number_input);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(NumeroText);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        text_input = new QLineEdit(NumeroText);
        text_input->setObjectName(QString::fromUtf8("text_input"));
        text_input->setStyleSheet(QString::fromUtf8("color: blue"));

        horizontalLayout_2->addWidget(text_input);


        verticalLayout->addLayout(horizontalLayout_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);

        erase_button = new QPushButton(NumeroText);
        erase_button->setObjectName(QString::fromUtf8("erase_button"));

        horizontalLayout_3->addWidget(erase_button);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_4);

        exit_button = new QPushButton(NumeroText);
        exit_button->setObjectName(QString::fromUtf8("exit_button"));

        horizontalLayout_4->addWidget(exit_button);


        verticalLayout->addLayout(horizontalLayout_4);


        retranslateUi(NumeroText);
        QObject::connect(exit_button, SIGNAL(clicked()), NumeroText, SLOT(close()));

        QMetaObject::connectSlotsByName(NumeroText);
    } // setupUi

    void retranslateUi(QWidget *NumeroText)
    {
        NumeroText->setWindowTitle(QApplication::translate("NumeroText", "Form", nullptr));
        label->setText(QApplication::translate("NumeroText", "N\303\272mero", nullptr));
        number_input->setText(QString());
        label_2->setText(QApplication::translate("NumeroText", "Text", nullptr));
        erase_button->setText(QApplication::translate("NumeroText", "Esborrar", nullptr));
        exit_button->setText(QApplication::translate("NumeroText", "Sortir", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NumeroText: public Ui_NumeroText {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NUMEROTEXT_H
