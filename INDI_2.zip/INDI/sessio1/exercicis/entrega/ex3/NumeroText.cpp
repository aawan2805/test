#include "NumeroText.h"
#include <iostream>
#include <QDebug>

NumeroText::NumeroText(QWidget* parent): QWidget(parent) {
    ui.setupUi(this);
    this->setWindowTitle("Número i text");
    // Max length of 10 chars.
    ui.text_input->setMaxLength(10);
    ui.number_input->setMaxLength(10);

    connect(ui.erase_button, SIGNAL(clicked()), this, SLOT(esborra()));
    connect(ui.number_input, SIGNAL(textChanged(QString)), this, SLOT(CanviInputNumero(QString)));
    connect(ui.text_input, SIGNAL(textChanged(QString)), this, SLOT(CanviInputText(QString)));
}

void NumeroText::esborra() {
    ui.text_input->setText("");
    ui.number_input->setText("");
}

void NumeroText::CanviInputNumero(QString str) {
    bool es_enter;
    str.toInt(&es_enter, 10);
    if(not es_enter){
        QString original_text = ui.number_input->text();
        original_text = original_text.remove(original_text.size()-1, original_text.size());
        ui.number_input->setText(original_text);
    }
}

void NumeroText::CanviInputText(QString str) {
    QCharRef ltr = str[str.size()-1];
    if(not ((ltr >= 65 and ltr <= 90) or (ltr >= 97 and ltr <= 122))){
        QString original_text = ui.text_input->text();
        original_text = original_text.remove(original_text.size()-1, original_text.size());
        ui.text_input->setText(original_text);
    }
}