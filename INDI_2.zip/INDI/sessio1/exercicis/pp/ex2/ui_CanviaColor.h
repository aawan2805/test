/********************************************************************************
** Form generated from reading UI file 'CanviaColor.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CANVIACOLOR_H
#define UI_CANVIACOLOR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *text;
    QSpacerItem *verticalSpacer_2;
    QPushButton *vermell;
    QSpacerItem *horizontalSpacer;
    QPushButton *blau;
    QSpacerItem *verticalSpacer;

    void setupUi(QWidget *Form)
    {
        if (Form->objectName().isEmpty())
            Form->setObjectName(QString::fromUtf8("Form"));
        Form->resize(400, 300);
        verticalLayout = new QVBoxLayout(Form);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        text = new QLabel(Form);
        text->setObjectName(QString::fromUtf8("text"));

        verticalLayout->addWidget(text);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        vermell = new QPushButton(Form);
        vermell->setObjectName(QString::fromUtf8("vermell"));

        verticalLayout->addWidget(vermell);

        horizontalSpacer = new QSpacerItem(379, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        verticalLayout->addItem(horizontalSpacer);

        blau = new QPushButton(Form);
        blau->setObjectName(QString::fromUtf8("blau"));

        verticalLayout->addWidget(blau);

        verticalSpacer = new QSpacerItem(20, 90, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        verticalLayout->setStretch(0, 1);
        verticalLayout->setStretch(2, 2);
        verticalLayout->setStretch(5, 2);

        retranslateUi(Form);

        QMetaObject::connectSlotsByName(Form);
    } // setupUi

    void retranslateUi(QWidget *Form)
    {
        Form->setWindowTitle(QApplication::translate("Form", "Form", nullptr));
        text->setText(QApplication::translate("Form", "Soc el text que cambiar\303\240 de color jejejeje", nullptr));
        vermell->setText(QApplication::translate("Form", "Vermell", nullptr));
        blau->setText(QApplication::translate("Form", "Blau", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Form: public Ui_Form {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CANVIACOLOR_H
