#include "CanviaColor.h"
#include <iostream>
// #include <QDebug>

double result = 0.0;

Form::Form(QWidget* parent): QWidget(parent) {
    ui.setupUi(this);
    this->setWindowTitle("Canvia de fons al text");

    connect(ui.vermell, SIGNAL(clicked(bool)), this, SLOT(canviaFonsVermell()));
    connect(ui.blau, SIGNAL(clicked(bool)), this, SLOT(canviaFonsBlau()));
}

void Form::canviaFonsVermell(){
    ui.text->setStyleSheet("background-color: red");
}

void Form::canviaFonsBlau(){
    ui.text->setStyleSheet("background-color: blue");
}
