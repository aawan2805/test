#include "Form.h"
#include <iostream>
// #include <QDebug>

double result = 0.0;

Form::Form(QWidget* parent): QWidget(parent) {
    ui.setupUi(this);
    this->setWindowTitle("Conversor de milles i KMs");

    connect(ui.pushButton_2, SIGNAL(clicked(bool)), this, SLOT(checkboxChanges()));
}

void Form::checkboxChanges(){
    int val = ui.spinBox->value();
    if(ui.radioButton->isChecked()){
        // From KM to miles
        val = (int) val/1.60934;
    } else {
        val = (int) val*1.60934;
    }
    ui.spinBox_2->setValue(val);
}
