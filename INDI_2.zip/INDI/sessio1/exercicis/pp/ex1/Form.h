#include "ui_Form.h"

class Form : public QWidget {
    Q_OBJECT
    public: 
        Form(QWidget *parent = NULL);
    private:
        Ui::Form ui;
    private slots:
        void checkboxChanges();
};