
GLunit VAO1;

glGenVertexArrays(1, &VAO1);


// glGenVertexArrays(..., puntero a VAOS o GLunit*)
glBindBuffer(GL_ARRAY_BUFFER, VA01);


glm::vec3 Vertices[] = {
	glm::vec3(-1.0, -1.0, 0.0);
	glm::vec3(1.0, -1.0, 0.0);
	glm::vec3(0.0, 1.0, 0.0);
}